<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'DB/db_connection.php'; // Connexion à la base de données

if (isset($_POST['email']) && filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    $email = $_POST['email'];

    // Rechercher l'ID de l'utilisateur à partir de l'e-mail
    $stmt = $conn->prepare("SELECT id FROM utilisateurs WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $utilisateur_id = $user['id'];

        // Générer un token unique et un timestamp
        $token = bin2hex(random_bytes(32));
        $timestamp = time();

        // Insérer le token et le timestamp dans la table reset_tokens
        $stmt = $conn->prepare("INSERT INTO reset_tokens (utilisateur_id, token, timestamp) VALUES (?, ?, ?)");
        $stmt->bind_param("isi", $utilisateur_id, $token, $timestamp);
        $stmt->execute();

        // Lien de réinitialisation avec l'ID de l'utilisateur
        $resetLink = "http://localhost/location_voitures/reinitialiser_mdp.php?id=" . $utilisateur_id;

        // Configuration et envoi de l’e-mail avec PHPMailer
        $mail = new PHPMailer(true);
        try {
            $mail->SMTPDebug = 0;
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'aymenhalleb01@gmail.com'; // Adresse Gmail
            $mail->Password = 'mssu vyet yygm evfg';    // Mot de passe Gmail
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('aymenhalleb01@gmail.com', 'Location Voitures');
            $mail->addAddress($email); // Destinataire

            $mail->isHTML(true);
            $mail->Subject = 'Réinitialisation de votre mot de passe';
            $mail->Body = "Bonjour,<br>Cliquez sur le lien ci-dessous pour réinitialiser votre mot de passe (valide 10 minutes) :<br>
                           <a href='$resetLink'>$resetLink</a>";
            $mail->AltBody = "Cliquez sur ce lien pour réinitialiser votre mot de passe : $resetLink";

            $mail->send();
            echo 'Un e-mail de réinitialisation a été envoyé à votre adresse si elle est correcte.';
        } catch (Exception $e) {
            echo "Erreur lors de l’envoi de l’e-mail : {$mail->ErrorInfo}";
        }
    } else {
        echo "Aucun utilisateur trouvé avec cet e-mail.";
    }
} else {
    echo "Adresse e-mail invalide.";
}
?>
