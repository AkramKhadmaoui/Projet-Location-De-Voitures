<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mot de passe oublié</title>
    <link rel="stylesheet" href="styles_css/forgot_password.css">
</head>
<header>
    <?php include('includes/includes_header.php'); ?>
</header>


<body>
    <div class="image-container">
        <img src="background.jpg" alt="Fond" class="image_voiture">
    </div>

    <div class="forgot-password-container">
        <h2>Réinitialiser votre mot de passe</h2>
        <form method="POST" action="envoyer_mail.php">
            <div>
                <label for="email">Entrez votre adresse e-mail :</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div>
                <button type="submit">Envoyer un lien de réinitialisation</button>
            </div>
        </form>
    </div>
</body>
</html>