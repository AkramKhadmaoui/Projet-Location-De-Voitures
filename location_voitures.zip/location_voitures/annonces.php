<?php
session_start();
include 'DB/db_connection.php'; // Include your database connection file.

try {
    // Initialize the base query
   $sql = "SELECT *, utilisateur_id FROM annonces 
           WHERE est_reservee = 'non réservée' 
           AND statut = 'validée'";

    // Build dynamic conditions
    $conditions = [];
    $params = [];

    if (!empty($_POST['price_min'])) {
        $conditions[] = "prix_par_jour >= ?";
        $params[] = intval($_POST['price_min']);
    }
    if (!empty($_POST['price_max'])) {
        $conditions[] = "prix_par_jour <= ?";
        $params[] = intval($_POST['price_max']);
    }
    if (!empty($_POST['marque'])) {
        $conditions[] = "marque LIKE ?";
        $params[] = '%' . $conn->real_escape_string($_POST['marque']) . '%';
    }

    // Append conditions to the query
    if (!empty($conditions)) {
        $sql .= " AND " . implode(" AND ", $conditions);
    }

    // Order by price if specified
    if (!empty($_POST['tri'])) {
        if ($_POST['tri'] === 'prix_croissant') {
            $sql .= " ORDER BY prix_par_jour ASC";
        } elseif ($_POST['tri'] === 'prix_decroissant') {
            $sql .= " ORDER BY prix_par_jour DESC";
        }
    } else {
        $sql .= " ORDER BY date_creation DESC";
    }

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Bind parameters dynamically
        if (!empty($params)) {
            $types = str_repeat('s', count($params)); // Adjust types if needed, 's' for string
            $stmt->bind_param($types, ...$params);
        }

        // Execute the query
        $stmt->execute();
        $result = $stmt->get_result();

        // Fetch the results directly without storing them in the session
        $annonces = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        throw new Exception("Erreur dans la préparation de la requête.");
    }
} catch (Exception $e) {
    // Handle errors gracefully
    $annonces = [];
    $error_message = "Erreur : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Résultats de recherche</title>
    <link rel="stylesheet" href="styles_css/annonces.css"> 
</head>
<body>

<header>
    <?php include('includes/includes_header.php'); ?>
</header>

<div class="page-container">
    <!-- Section des filtres -->
    <div class="filtre-container">
        <h1>QUELLE VOITURE VOULEZ-VOUS CONDUIRE ?</h1>
        <form method="POST" action="">
            <div class="filtre">
                <label for="prix-min">Prix (Min) :</label>
                <input type="number" id="prix-min" name="price_min" placeholder="Min" value="<?= htmlspecialchars($_POST['price_min'] ?? '') ?>">
                <label for="prix-max">Prix (Max) :</label>
                <input type="number" id="prix-max" name="price_max" placeholder="Max" value="<?= htmlspecialchars($_POST['price_max'] ?? '') ?>">
            </div>

            <div class="filtre">
                <label for="marque">Marque :</label>
                <select id="marque" name="marque">
                    <option value="">Toutes les marques</option>
                    <!-- Options des marques -->
                    <option value="Acura" <?= ($_POST['marque'] ?? '') === 'Acura' ? 'selected' : '' ?>>Acura</option>
                    <option value="Alfa Romeo" <?= ($_POST['marque'] ?? '') === 'Alfa Romeo' ? 'selected' : '' ?>>Alfa Romeo</option>
                    <option value="Aston Martin" <?= ($_POST['marque'] ?? '') === 'Aston Martin' ? 'selected' : '' ?>>Aston Martin</option>
                    <option value="Audi" <?= ($_POST['marque'] ?? '') === 'Audi' ? 'selected' : '' ?>>Audi</option>
                    <option value="Bentley" <?= ($_POST['marque'] ?? '') === 'Bentley' ? 'selected' : '' ?>>Bentley</option>
                    <option value="BMW" <?= ($_POST['marque'] ?? '') === 'BMW' ? 'selected' : '' ?>>BMW</option>
                    <option value="Bugatti" <?= ($_POST['marque'] ?? '') === 'Bugatti' ? 'selected' : '' ?>>Bugatti</option>
                    <option value="Buick" <?= ($_POST['marque'] ?? '') === 'Buick' ? 'selected' : '' ?>>Buick</option>
                    <option value="Cadillac" <?= ($_POST['marque'] ?? '') === 'Cadillac' ? 'selected' : '' ?>>Cadillac</option>
                    <option value="Chevrolet" <?= ($_POST['marque'] ?? '') === 'Chevrolet' ? 'selected' : '' ?>>Chevrolet</option>
                    <option value="Chrysler" <?= ($_POST['marque'] ?? '') === 'Chrysler' ? 'selected' : '' ?>>Chrysler</option>
                    <option value="Citroën" <?= ($_POST['marque'] ?? '') === 'Citroën' ? 'selected' : '' ?>>Citroën</option>
                    <option value="Dacia" <?= ($_POST['marque'] ?? '') === 'Dacia' ? 'selected' : '' ?>>Dacia</option>
                    <option value="Daewoo" <?= ($_POST['marque'] ?? '') === 'Daewoo' ? 'selected' : '' ?>>Daewoo</option>
                    <option value="Daihatsu" <?= ($_POST['marque'] ?? '') === 'Daihatsu' ? 'selected' : '' ?>>Daihatsu</option>
                    <option value="Dodge" <?= ($_POST['marque'] ?? '') === 'Dodge' ? 'selected' : '' ?>>Dodge</option>
                    <option value="Ferrari" <?= ($_POST['marque'] ?? '') === 'Ferrari' ? 'selected' : '' ?>>Ferrari</option>
                    <option value="Fiat" <?= ($_POST['marque'] ?? '') === 'Fiat' ? 'selected' : '' ?>>Fiat</option>
                    <option value="Ford" <?= ($_POST['marque'] ?? '') === 'Ford' ? 'selected' : '' ?>>Ford</option>
                    <option value="Genesis" <?= ($_POST['marque'] ?? '') === 'Genesis' ? 'selected' : '' ?>>Genesis</option>
                    <option value="GMC" <?= ($_POST['marque'] ?? '') === 'GMC' ? 'selected' : '' ?>>GMC</option>
                    <option value="Honda" <?= ($_POST['marque'] ?? '') === 'Honda' ? 'selected' : '' ?>>Honda</option>
                    <option value="Hummer" <?= ($_POST['marque'] ?? '') === 'Hummer' ? 'selected' : '' ?>>Hummer</option>
                    <option value="Hyundai" <?= ($_POST['marque'] ?? '') === 'Hyundai' ? 'selected' : '' ?>>Hyundai</option>
                    <option value="Infiniti" <?= ($_POST['marque'] ?? '') === 'Infiniti' ? 'selected' : '' ?>>Infiniti</option>
                    <option value="Jaguar" <?= ($_POST['marque'] ?? '') === 'Jaguar' ? 'selected' : '' ?>>Jaguar</option>
                    <option value="Jeep" <?= ($_POST['marque'] ?? '') === 'Jeep' ? 'selected' : '' ?>>Jeep</option>
                    <option value="Kia" <?= ($_POST['marque'] ?? '') === 'Kia' ? 'selected' : '' ?>>Kia</option>
                    <option value="Koenigsegg" <?= ($_POST['marque'] ?? '') === 'Koenigsegg' ? 'selected' : '' ?>>Koenigsegg</option>
                    <option value="Lamborghini" <?= ($_POST['marque'] ?? '') === 'Lamborghini' ? 'selected' : '' ?>>Lamborghini</option>
                    <option value="Lancia" <?= ($_POST['marque'] ?? '') === 'Lancia' ? 'selected' : '' ?>>Lancia</option>
                    <option value="Land Rover" <?= ($_POST['marque'] ?? '') === 'Land Rover' ? 'selected' : '' ?>>Land Rover</option>
                    <option value="Lexus" <?= ($_POST['marque'] ?? '') === 'Lexus' ? 'selected' : '' ?>>Lexus</option>
                    <option value="Lincoln" <?= ($_POST['marque'] ?? '') === 'Lincoln' ? 'selected' : '' ?>>Lincoln</option>
                    <option value="Lotus" <?= ($_POST['marque'] ?? '') === 'Lotus' ? 'selected' : '' ?>>Lotus</option>
                    <option value="Maserati" <?= ($_POST['marque'] ?? '') === 'Maserati' ? 'selected' : '' ?>>Maserati</option>
                    <option value="Mazda" <?= ($_POST['marque'] ?? '') === 'Mazda' ? 'selected' : '' ?>>Mazda</option>
                    <option value="McLaren" <?= ($_POST['marque'] ?? '') === 'McLaren' ? 'selected' : '' ?>>McLaren</option>
                    <option value="Mercedes-Benz" <?= ($_POST['marque'] ?? '') === 'Mercedes-Benz' ? 'selected' : '' ?>>Mercedes-Benz</option>
                    <option value="Mini" <?= ($_POST['marque'] ?? '') === 'Mini' ? 'selected' : '' ?>>Mini</option>
                    <option value="Mitsubishi" <?= ($_POST['marque'] ?? '') === 'Mitsubishi' ? 'selected' : '' ?>>Mitsubishi</option>
                    <option value="Nissan" <?= ($_POST['marque'] ?? '') === 'Nissan' ? 'selected' : '' ?>>Nissan</option>
                    <option value="Opel" <?= ($_POST['marque'] ?? '') === 'Opel' ? 'selected' : '' ?>>Opel</option>
                    <option value="Peugeot" <?= ($_POST['marque'] ?? '') === 'Peugeot' ? 'selected' : '' ?>>Peugeot</option>
                    <option value="Porsche" <?= ($_POST['marque'] ?? '') === 'Porsche' ? 'selected' : '' ?>>Porsche</option>
                    <option value="Ram" <?= ($_POST['marque'] ?? '') === 'Ram' ? 'selected' : '' ?>>Ram</option>
                    <option value="Renault" <?= ($_POST['marque'] ?? '') === 'Renault' ? 'selected' : '' ?>>Renault</option>
                    <option value="Rolls-Royce" <?= ($_POST['marque'] ?? '') === 'Rolls-Royce' ? 'selected' : '' ?>>Rolls-Royce</option>
                    <option value="Saab" <?= ($_POST['marque'] ?? '') === 'Saab' ? 'selected' : '' ?>>Saab</option>
                    <option value="Seat" <?= ($_POST['marque'] ?? '') === 'Seat' ? 'selected' : '' ?>>Seat</option>
                    <option value="Skoda" <?= ($_POST['marque'] ?? '') === 'Skoda' ? 'selected' : '' ?>>Skoda</option>
                    <option value="Smart" <?= ($_POST['marque'] ?? '') === 'Smart' ? 'selected' : '' ?>>Smart</option>
                    <option value="Subaru" <?= ($_POST['marque'] ?? '') === 'Subaru' ? 'selected' : '' ?>>Subaru</option>
                    <option value="Suzuki" <?= ($_POST['marque'] ?? '') === 'Suzuki' ? 'selected' : '' ?>>Suzuki</option>
                    <option value="Tesla" <?= ($_POST['marque'] ?? '') === 'Tesla' ? 'selected' : '' ?>>Tesla</option>
                    <option value="Toyota" <?= ($_POST['marque'] ?? '') === 'Toyota' ? 'selected' : '' ?>>Toyota</option>
                    <option value="Volkswagen" <?= ($_POST['marque'] ?? '') === 'Volkswagen' ? 'selected' : '' ?>>Volkswagen</option>
                    <option value="Volvo" <?= ($_POST['marque'] ?? '') === 'Volvo' ? 'selected' : '' ?>>Volvo</option>
                </select>
            </div>

            <div class="filtre">
                <label>Tri :</label>
                <label><input type="radio" name="tri" value="prix_croissant" <?= ($_POST['tri'] ?? '') === 'prix_croissant' ? 'checked' : '' ?>> Prix croissant</label>
                <label><input type="radio" name="tri" value="prix_decroissant" <?= ($_POST['tri'] ?? '') === 'prix_decroissant' ? 'checked' : '' ?>> Prix décroissant</label>
            </div>

            <button type="submit" class="bouton-appliquer">Appliquer</button>
        </form>
    </div>

    <!-- Section des annonces -->
    <div class="annonces-container">
    <div style="text-align:center; margin-bottom: 20px; margin-top: -10px;">
        <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])): ?>
            <a href="deposer_annonce.php" class="btn-deposer-annonce">Déposer une annonce</a>
        <?php else: ?>
            <p class="phrase-rouge">Connectez-vous pour déposer une annonce</p>
        <?php endif; ?>
    </div>
    <h2 style="text-align:center;">Annonces Disponibles</h2>
    <?php if (!empty($annonces)): ?>
        <div class="annonces-grid">
            <?php foreach ($annonces as $annonce): ?>
                <div class="annonce-card">
                    <img src="<?= htmlspecialchars($annonce['photo'] ?? 'default-image.jpg') ?>" alt="Photo de <?= htmlspecialchars($annonce['marque']) ?>">
                    <div class="annonce-card-content">
                        <h3><?= htmlspecialchars($annonce['marque']) ?> <?= htmlspecialchars($annonce['modele']) ?></h3>
                        <p class="price">Prix: <?= htmlspecialchars($annonce['prix_par_jour']) ?> € / jour</p>
                        <p><?= htmlspecialchars($annonce['description']) ?></p>
                        <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])): ?>
                            <?php if ($_SESSION['user_id'] !== $annonce['utilisateur_id']): ?>
                                <form action="process/process_reservation.php" method="POST">
                                    <input type="hidden" name="annonce_id" value="<?= htmlspecialchars($annonce['id']) ?>">
                                    <button type="submit" class="btn-reserver">Réserver</button>
                                </form>
                            <?php else: ?>
                                <p style="color: green; font-size: 14px;">Votre annonce</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p style="color: red; font-size: 14px;">Connectez-vous pour réserver</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php elseif (!empty($error_message)): ?>
        <p class="message-erreur">Erreur: <?= htmlspecialchars($error_message) ?></p>
    <?php else: ?>
        <p>Aucune annonce trouvée.</p>
    <?php endif; ?>
</div>
</div>

<footer>
    <?php include('includes/includes_footer.php'); ?>
</footer>

</body>
</html>