<div class="footer-dark">
    <footer>
        <div class="container">
            <div class="row">
                <!-- Colonne gauche : About -->
                <div class="col-sm-6 col-md-3 item">
                    <h3>Contact US</h3>
                    <ul>
                        <li><a href="#">+33 6 29 21 08 00</a></li>
                    </ul>
                </div>

           

                <!-- Colonne droite : Company Name -->
                <div class="col-sm-6 col-md-3 item">
                    <h3>Company Name</h3>
                    <p>
                        Chez L<img src="/location_voitures/images/roue.jpg" alt="Roue" class="logo-wheell">
                        CAR, nous sommes dédiés à fournir des solutions de location de voitures fiables et abordables. 
                        Voyagez en toute tranquillité avec notre flotte variée, adaptée à tous vos besoins. 
                        Contactez-nous pour des services sur mesure et une expérience exceptionnelle.
                    </p>
                </div>
            </div>

            <!-- Ligne séparée pour le copyright -->
            <div class="row">
                <div class="col-12 text-center">
                    <p class="copyright">
                        L<img src="/location_voitures/images/roue.jpg" alt="Roue" class="logo-wheell">CAR © 2025
                    </p>
                </div>
            </div>
        </div>
    </footer>
</div>
