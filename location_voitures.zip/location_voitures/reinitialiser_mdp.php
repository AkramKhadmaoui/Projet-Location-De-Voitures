<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation du mot de passe</title>
    <link rel="stylesheet" href="styles_css/reinitialiser_mdp.css">
</head>
<body>
<?php
    include("DB/db_connection.php");
    include("includes/includes_header.php");

    // Vérification que l'ID de l'utilisateur est bien passé dans l'URL
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "<p style='color: red; text-align: center;'>ID utilisateur manquant.</p>";
        exit;
    }

    $utilisateur_id = intval($_GET['id']);
    ?>
    <div class="reset-password-container">
        <h2>Réinitialisation du mot de passe</h2>
        <p>Veuillez entrer un nouveau mot de passe pour votre compte.</p>
        <form action="process/process_reinitialiser_mdp.php" method="POST">
            <!-- Champ caché pour envoyer l'ID de l'utilisateur -->
            <input type="hidden" name="utilisateur_id" value="12345">
            
            <div class="form-group">
                <label for="password">Nouveau mot de passe :</label>
                <input type="password" id="password" name="new_password" placeholder="Entrez votre nouveau mot de passe" required>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirmer le mot de passe :</label>
                <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirmez votre mot de passe" required>
            </div>
            <div class="form-group">
                <button type="submit" class="btn-submit">Réinitialiser</button>
            </div>
        </form>
    </div>
</body>
</html>
