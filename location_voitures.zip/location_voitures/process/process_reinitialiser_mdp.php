<?php
include('../DB/db_connection.php');

if (!empty($_POST['new_password']) && !empty($_POST['confirm_password']) && !empty($_POST['utilisateur_id'])) {
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    $utilisateur_id = intval($_POST['utilisateur_id']);

    // Vérifier que les deux mots de passe sont identiques
    if ($new_password === $confirm_password) {
        // Hacher le nouveau mot de passe
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Mettre à jour le mot de passe dans la base de données
        $stmt = $conn->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $utilisateur_id);

        if ($stmt->execute()) {
            // Supprimer le token utilisé (optionnel si un système de token est en place)
            $deleteToken = $conn->prepare("DELETE FROM reset_tokens WHERE utilisateur_id = ?");
            $deleteToken->bind_param("i", $utilisateur_id);
            $deleteToken->execute();

            echo "<script>alert('Mot de passe réinitialisé avec succès. Vous allez être redirigé vers la page de connexion.'); window.location.href = '../login.php';</script>";
        } else {
            echo "<p style='color: red;'>Erreur lors de la mise à jour du mot de passe : " . $conn->error . "</p>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Les mots de passe ne correspondent pas.'); window.history.back();</script>";
    }
} else {
    echo "<p style='color: red;'>Veuillez remplir tous les champs.</p>";
}

$conn->close();
?>
