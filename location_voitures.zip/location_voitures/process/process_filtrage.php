<?php
session_start();
include '../DB/db_connection.php'; // Include database connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        // Initialize the base query
        $sql = "SELECT * FROM annonces WHERE est_reservee = 'non réservée' AND statut = 'validée'";

        // Build dynamic conditions
        $conditions = [];
        $params = [];

        if (!empty($_POST['price_min'])) {
            $conditions[] = "prix_par_jour >= ?";
            $params[] = intval($_POST['price_min']);
        }
        if (!empty($_POST['price_max'])) {
            $conditions[] = "prix_par_jour <= ?";
            $params[] = intval($_POST['price_max']);
        }
        if (!empty($_POST['marque'])) {
            $conditions[] = "marque LIKE ?";
            $params[] = '%' . $_POST['marque'] . '%';
        }

        // Append conditions to the query
        if (!empty($conditions)) {
            $sql .= " AND " . implode(" AND ", $conditions);
        }

        // Add sorting
        $tri = $_POST['tri'] ?? '';
        if ($tri === 'prix_croissant') {
            $sql .= " ORDER BY prix_par_jour ASC";
        } elseif ($tri === 'prix_decroissant') {
            $sql .= " ORDER BY prix_par_jour DESC";
        } else {
            $sql .= " ORDER BY date_creation DESC";
        }

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        if (!empty($params)) {
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
        }

        // Execute query
        $stmt->execute();
        $result = $stmt->get_result();
        $resultats = $result->fetch_all(MYSQLI_ASSOC);

        // Store results in session
        $_SESSION['resultats'] = $resultats;

        // Check if no results
        if (empty($resultats)) {
            $_SESSION['message'] = "Aucune annonce ne correspond aux filtres appliqués.";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['message'] = "Erreur : " . $e->getMessage();
    }

    // Redirect to the results page
    header("Location: ../annonces.php");
    exit();
}
?>
