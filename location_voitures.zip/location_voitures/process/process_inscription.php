<?php
// Inclure la connexion à la base de données
include('../DB/db_connection.php');

// Démarrer la session pour gérer les messages d'erreur et de succès
session_start();

// Vérifier que le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer et valider les données du formulaire
    $nom = isset($_POST['nom']) ? trim($_POST['nom']) : null;
    $prenom = isset($_POST['prenom']) ? trim($_POST['prenom']) : null;
    $email = isset($_POST['email']) ? trim($_POST['email']) : null;
    $mot_de_passe = isset($_POST['mot_de_passe']) ? trim($_POST['mot_de_passe']) : null;
    $confirmer_mot_de_passe = isset($_POST['confirmer_mot_de_passe']) ? trim($_POST['confirmer_mot_de_passe']) : null;
    $date_naissance = isset($_POST['date_naissance']) ? trim($_POST['date_naissance']) : null;
    $numero_telephone = isset($_POST['numero_telephone']) ? trim($_POST['numero_telephone']) : null;
    $adresse_domicile = isset($_POST['adresse_domicile']) ? trim($_POST['adresse_domicile']) : null;
    $sexe = isset($_POST['sexe']) ? trim($_POST['sexe']) : null;

    // Vérifier que tous les champs sont remplis
    if (empty($nom) || empty($prenom) || empty($email) || empty($mot_de_passe) || empty($confirmer_mot_de_passe) || empty($date_naissance) || empty($numero_telephone) || empty($adresse_domicile) || empty($sexe)) {
        $_SESSION['error'] = "Tous les champs sont requis.";
        header("Location: ../inscription.php");
        exit;
    }

    // Vérifier si la date de naissance est valide et calculer l'âge
    try {
        $date_actuelle = new DateTime();
        $date_naissance_obj = new DateTime($date_naissance);
        $age = $date_actuelle->diff($date_naissance_obj)->y;

        if ($age < 18) {
            $_SESSION['error'] = "Vous devez avoir au moins 18 ans pour vous inscrire.";
            header("Location: ../inscription.php");
            exit;
        }
    } catch (Exception $e) {
        $_SESSION['error'] = "La date de naissance est invalide.";
        header("Location: ../inscription.php");
        exit;
    }

    // Vérifier que le mot de passe contient au moins 8 caractères, une lettre et un chiffre
    if (!preg_match('/^(?=.*[A-Za-z])(?=.*\d).{8,}$/', $mot_de_passe)) {
        $_SESSION['error'] = "Le mot de passe doit contenir au moins 8 caractères, une lettre et un chiffre.";
        header("Location: ../inscription.php");
        exit;
    }

    // Vérifier si les mots de passe correspondent
    if ($mot_de_passe !== $confirmer_mot_de_passe) {
        $_SESSION['error'] = "Les mots de passe ne correspondent pas.";
        header("Location: ../inscription.php");
        exit;
    }

    // Vérifier si l'email est valide
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Adresse email invalide.";
        header("Location: ../inscription.php");
        exit;
    }

    // Vérifier si l'email existe déjà
    $sql_check_email = "SELECT id FROM utilisateurs WHERE email = ?";
    $stmt = $conn->prepare($sql_check_email);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email déjà utilisé
        $_SESSION['error'] = "Cet email est déjà utilisé.";
        header("Location: ../inscription.php");
        exit;
    }

    // Hasher le mot de passe pour la sécurité
    $mot_de_passe_hache = password_hash($mot_de_passe, PASSWORD_DEFAULT);

    // Définir le rôle par défaut comme "utilisateur"
    $role = "utilisateur";

    // Insérer le nouvel utilisateur dans la base de données
    $sql_insert_user = "INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, date_naissance, numero_telephone, adresse_domicile, sexe, role, date_creation) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql_insert_user);
    $stmt->bind_param("sssssssss", $nom, $prenom, $email, $mot_de_passe_hache, $date_naissance, $numero_telephone, $adresse_domicile, $sexe, $role);

    if ($stmt->execute()) {
        // Succès de l'inscription
        $_SESSION['success'] = "Inscription réussie ! Vous pouvez maintenant vous connecter.";
        header("Location: ../index.php");
        exit;
    } else {
        // Erreur lors de l'insertion
        $_SESSION['error'] = "Une erreur est survenue. Veuillez réessayer.";
        header("Location: ../inscription.php");
        exit;
    }
    
    // Fermer la connexion
    $stmt->close();
    $conn->close();
} else {
    // Rediriger vers la page d'inscription si l'accès direct est tenté
    header("Location: ../inscription.php");
    exit;
}
?>
