// Initialisation des variables
let currentSlide = 0;
const slides = document.querySelectorAll('.slide'); // Récupérer tous les avis
const totalSlides = slides.length; // Nombre total d'avis

// Fonction pour afficher le slide actif
function showSlide(index) {
    slides.forEach((slide, i) => {
        if (i === index) {
            slide.classList.add('active');
        } else {
            slide.classList.remove('active');
        }
    });
}

// Fonction pour passer au slide suivant
function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides; // Passer au suivant, boucler si nécessaire
    showSlide(currentSlide);
}

// Fonction pour revenir au slide précédent
function prevSlide() {
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides; // Revenir au précédent, boucler si nécessaire
    showSlide(currentSlide);
}

// Initialiser le premier slide
showSlide(currentSlide);
