<?php
// Démarrer la session
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord utilisateur</title>
    <link rel="stylesheet" href="../styles_css/utilisateur_dashboard.css">
</head>
<body>

<header>
    <?php include('../includes/includes_header.php'); ?>
</header>

<div class="hero_container">
    <!-- Bannière principale -->
    <div class="hero-banner">
        <h1>Bienvenue sur L<img src="/location_voitures/images/roue.jpg" alt="Roue" class="logo-wheel">CAR</h1>
        <h2>Gérez vos réservations et explorez nos offres exclusives.</h2>
    </div>
</div>

<!-- Message de connexion/déconnexion -->
<div class="status-connexion">
    <?php if (isset($_SESSION['user_id'])): ?>
        <p>Vous êtes connecté en tant que <strong><?php echo htmlspecialchars($_SESSION['prenom']) . " " . htmlspecialchars($_SESSION['nom']); ?></strong></p>
    <?php else: ?>
        <p>Vous n'êtes pas connecté</p>
    <?php endif; ?>
</div>

<!-- Barre de réservation -->
<div class="section-container">
    <div class="reservation-bar">
        <form action="../process/process_filtrage.php" method="POST">
            <!-- Lieu de prise en charge -->
            <div class="location">
                <label for="location">Lieu de prise en charge</label>
                <input type="text" id="location" name="location" placeholder="Calais, Pas-de-Calais, France" required>
            </div>

            <!-- Date de début -->
            <div class="date">
                <label for="date_debut">Date de début</label>
                <input type="date" id="date_debut" name="date_debut" required>
            </div>

            <!-- Heure de début -->
            <div class="time">
                <label for="heure_debut">Heure de début</label>
                <input type="time" id="heure_debut" name="heure_debut" required>
            </div>

            <!-- Date de fin -->
            <div class="date">
                <label for="date_fin">Date de fin</label>
                <input type="date" id="date_fin" name="date_fin" required>
            </div>

            <!-- Heure de fin -->
            <div class="time">
                <label for="heure_fin">Heure de fin</label>
                <input type="time" id="heure_fin" name="heure_fin" required>
            </div>

            <!-- Bouton de recherche -->
            <div class="submit">
                <button type="submit" name="rechercher">Rechercher</button>
            </div>
        </form>
    </div>

    <!-- Image de promotion -->
    <div class="image-codepromo">
        <img src="/location_voitures/images/conduite.jpg" alt="conduite" class="Code-prom">
    </div>
</div>


<!-- Section des avis des clients -->
<div class="testimonial-section">
    <img src="/location_voitures/images/famille.jpg" alt="famille" class="testimonial-image">

    <div class="carousel">
        <!-- Avis dynamiques -->
        <div class="slides">
            <?php
            // Inclusion du fichier de connexion à la base de données
            include '../DB/db_connection.php';

            // Requête pour récupérer les avis avec les noms des utilisateurs
            $query = "SELECT u.nom, a.commentaire, a.date_avis 
                      FROM avis a 
                      JOIN utilisateurs u ON a.utilisateur_id = u.id 
                      ORDER BY a.date_avis DESC";
            $result = $conn->query($query);

            // Vérification et affichage des avis
            if ($result->num_rows > 0):
                while ($un_avis = $result->fetch_assoc()): ?>
                    <div class="slide">
                        <blockquote>
                            <p>"<?= htmlspecialchars($un_avis['commentaire']) ?>"</p>
                            <footer>— <?= htmlspecialchars($un_avis['nom']) ?></footer>
                        </blockquote>
                    </div>
                <?php endwhile;
            else: ?>
                <p>Aucun avis pour le moment.</p>
            <?php endif; ?>
        </div>

            <!-- Flèches -->
            <div class="controls">
                <span class="prev" onclick="prevSlide()">&#10094;</span>
                <span class="next" onclick="nextSlide()">&#10095;</span>
            </div>
    </div>
</div>



<footer>
    <?php include('../includes/includes_footer.php'); ?>
</footer>

<script src="../slide.js"></script>
</body>
</html>
