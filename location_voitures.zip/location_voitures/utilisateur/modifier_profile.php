<?php
// Démarrer la session
session_start();
require_once '../DB/db_connection.php';

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'client') {
    $_SESSION['error'] = "Veuillez vous connecter pour accéder à cette page.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Requête pour récupérer les informations utilisateur
$stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows == 0) {
    die("Erreur : utilisateur non trouvé.");
}

$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier mon profil</title>
    <link rel="stylesheet" href="../styles_css/modifier_profile.css">
</head>
<body>
    <header>
        <?php include('../includes/includes_header.php'); ?>
    </header>



    <div class="form-container">
        <h2>Modifier mon profil</h2>
        <form action="../process/process_modifier_profile.php" method="POST">
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($user['nom']); ?>" required>
            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" value="<?php echo htmlspecialchars($user['prenom']); ?>" required>
            <label for="email">Email :</label>
            <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            <label for="tel">Téléphone :</label>
            <input type="text" id="tel" name="tel" value="<?php echo htmlspecialchars($user['numero_telephone']); ?>" required>
            <label for="adresse">Adresse :</label>
            <input type="text" id="adresse" name="adresse" value="<?php echo htmlspecialchars($user['adresse_domicile']); ?>" required>
            <button type="submit">Enregistrer les modifications</button>
        </form>
    </div>

    <footer>
        <p>© 2024 Location de Voitures. Tous droits réservés.</p>
    </footer>
</body>
</html>
